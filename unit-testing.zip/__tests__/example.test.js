const sum = require('./example.js');

describe('sum function', () => {
	test('adds two numbers correctly', () => {
		expect(sum(1, 2)).toBe(3);
	});

	test('handles string arguments', () => {
		expect(sum("1", "2")).toBe("12");
		expect(sum("1", 2)).toBe("12");
	});

	test('handles null and undefined', () => {
		expect(sum(null, 2)).toBe(2);
		expect(sum(1, undefined)).toBe(NaN);
	});

	test('handles Infinity', () => {
		expect(sum(Infinity, 2)).toBe(Infinity);
	});

	test('handles NaN', () => {
		expect(sum(NaN, 2)).toBe(NaN);
	});


});