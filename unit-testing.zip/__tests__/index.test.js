const { main } = require('../src/index.js');

describe('main function', () => {
	test('calls getMonth and sum correctly', () => {
		// Здесь можно использовать mock-функции, если нужно проверить вызовы функций
		const consoleLogSpy = jest.spyOn(console, 'log').mockImplementation();

		main();

		expect(consoleLogSpy).toHaveBeenCalledWith('май');
		expect(consoleLogSpy).toHaveBeenCalledWith('Неверный номер месяца');
		expect(consoleLogSpy).toHaveBeenCalledWith(12);

		consoleLogSpy.mockRestore();
	});
});