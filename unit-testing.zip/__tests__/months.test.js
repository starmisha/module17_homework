// __tests__/months.test.js
const getMonth = require('../src/months.js');

describe('getMonth function', () => {
	// Минимальное значение
	test('returns correct month for minimum valid input (1)', () => {
		expect(getMonth(1)).toBe('январь');
	});

	// Максимальное значение
	test('returns correct month for maximum valid input (12)', () => {
		expect(getMonth(12)).toBe('декабрь');
	});

	// Значение меньше минимального
	test('returns error message for input less than 1 (0)', () => {
		expect(getMonth(0)).toBe('Неверный номер месяца');
	});

	// Значение больше максимального
	test('returns error message for input greater than 12 (13)', () => {
		expect(getMonth(13)).toBe('Неверный номер месяца');
	});

	// Нулевое значение
	test('returns error message for zero input (0)', () => {
		expect(getMonth(0)).toBe('Неверный номер месяца');
	});

	// Отрицательное значение
	test('returns error message for negative input (-1)', () => {
		expect(getMonth(-1)).toBe('Неверный номер месяца');
	});

	// Нечисловое значение (null)
	test('returns error message for null input', () => {
		expect(getMonth(null)).toBe('Неверный номер месяца');
	});

	// Нечисловое значение (undefined)
	test('returns error message for undefined input', () => {
		expect(getMonth(undefined)).toBe('Неверный номер месяца');
	});

	// Нечисловое значение (строка)
	test('returns error message for string input', () => {
		expect(getMonth('January')).toBe('Неверный номер месяца');
	});

	// Нечисловое значение (объект)
	test('returns error message for object input', () => {
		expect(getMonth({})).toBe('Неверный номер месяца');
	});
});