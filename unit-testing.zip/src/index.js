const { getMonth } = require('./months.js');
const { sum } = require('./example.js');

function main() {
	console.log(getMonth(5)); // Ожидаемый вывод: май
	console.log(getMonth(15)); // Ожидаемый вывод: Неверный номер месяца
	console.log(sum(5, 7)); // Ожидаемый вывод: 12
}

module.exports = { main };