module.exports = {
	testEnvironment: 'node',
};